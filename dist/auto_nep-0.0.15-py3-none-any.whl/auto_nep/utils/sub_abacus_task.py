#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：auto_nep
@File ：sub_abacus.py
@Author ：RongYi
@Date ：2025/6/8 11:23
@E-mail ：2071914258@qq.com
"""


