#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project ：auto_nep
@File ：__init__.py
@Author ：RongYi
@Date ：2025/5/4 12:27
@E-mail ：2071914258@qq.com
"""
from .sysprint import sysprint