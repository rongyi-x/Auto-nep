# auto-nep
auto-nep requires the following packages.
> pip install git+https://gitlab.com/1041176461/ase-abacus.git  
> pip install git+https://github.com/bigd4/PyNEP.git 

cupy uses your GPU and is much faster when performing MaxVol. Since you are using GPUMD, I assume you have a GPU. You can check its website for installation details.
> pip install cupy-cuda12x 

auto-nep based on the following projects
> https://github.com/psn417/nep_maker
